<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error Message Receiver</title>
</head>
<body>
    <p><h1>Error</h1></p>
    <center><div id="error-message"></div></center>

    <script>
        MsgTimedout = false
        function receiveMessage(event) {
            if(!MsgTimedout) {
             document.getElementById('error-message').textContent = event.data;
             clearInterval(timeoutTimer)
            } else {
             document.getElementById('error-message').textContent = "Received Message After timed out already.";
            }
        }
        window.addEventListener('message', receiveMessage);
        timeoutTimer = setTimeout(function () {
            document.getElementById('error-message').textContent = "Message timed out.";
            MsgTimedout = true
        }, 1000)
    </script>
</body>
</html>
