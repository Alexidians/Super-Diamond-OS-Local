<html>
<head></head>
<body>
<center><h1>System Info</h1></center>
<p><a href="php/index.html">PHP</a></p>
<p><a href="structure/index.html">System Structure</a></p>
</body>
</html>