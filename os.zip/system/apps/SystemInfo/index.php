<html>
<head></head>
<body>
<center><h1>System Info</h1></center>
<p><a href="phpinfo.php">PHP Info</a></p>
</body>
</html>