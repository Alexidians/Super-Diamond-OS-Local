<html>
<head></head>
<body>
<center><h1>System Info</h1></center>
<p><a href="php/index.html">PHP</a></p>
</body>
</html>