<?php
echo '<a href="index.html">Back</a>';
echo '<p>Minimum Int Size (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-int-min" target="_blank">PHP_INT_MIN</a>): ' . PHP_INT_MIN . '</p>';
echo '<p>Maximum Int Size (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-int-max" target="_blank">PHP_INT_MAX</a>): ' . PHP_INT_MAX . '</p>';
echo '<p>Int Byte Size (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-int-size" target="_blank">PHP_INT_SIZE</a>): ' . PHP_INT_SIZE . '</p>';
echo '<p>Minimum Float Size (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-float-min" target="_blank">PHP_FLOAT_MIN</a>): ' . PHP_FLOAT_MIN . '</p>';
echo '<p>Maximum Float Size (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-float-max" target="_blank">PHP_FLOAT_MAX</a>): ' . PHP_FLOAT_MAX . '</p>';
echo '<p>Decimal Digits roundable to float and back (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-float-dig" target="_blank">PHP_FLOAT_DIG</a>): ' . PHP_FLOAT_DIG . '</p>';
echo '<p>Smallest representable positive float: (<a href="https://www.php.net/manual/en/reserved.constants.php#constant.php-float-epsilon" target="_blank">PHP_FLOAT_EPSILON</a>): ' . PHP_FLOAT_EPSILON . '</p>';
?>