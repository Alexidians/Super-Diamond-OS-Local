<?php
echo '<a href="index.html">Back</a>';
echo '<p>Minimum Int Size: ' . PHP_INT_MIN . '</p>';
echo '<p>Maximum Int Size: ' . PHP_INT_MAX . '</p>';
echo '<p>Int Byte Size: ' . PHP_INT_SIZE . '</p>';
echo '<p>Minimum Float Size: ' . PHP_FLOAT_MIN . '</p>';
echo '<p>Maximum Float Size: ' . PHP_FLOAT_MAX . '</p>';
echo '<p>Decimal Digits roundable to float and back: ' . PHP_FLOAT_DIG . '</p>';
echo '<p>Smallest representable positive float: ' . PHP_FLOAT_EPSILON . '</p>';
?>