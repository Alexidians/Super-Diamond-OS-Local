<?php
echo '<a href="index.php">Back</a>';
phpinfo()
?>