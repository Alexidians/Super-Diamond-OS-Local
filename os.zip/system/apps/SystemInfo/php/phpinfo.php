<?php
echo '<a href="index.html">Back</a>';
phpinfo()
?>