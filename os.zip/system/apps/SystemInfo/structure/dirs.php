<?php
echo '<a href=".../index.php">Back</a>';
echo '<p>System Directory: ' . realpath('../../../') . '</p>';
echo '<p>App Directory: ' . realpath('../../') . '</p>';
echo '<p>Installation Directory: ' . realpath('../../../../') . '</p>';
echo '<p>PHP Configuration Directory: ' . realpath('../../../php') . '</p>';
echo '<p>Icon Directory: ' . realpath('../../../icons') . '</p>';
echo '<p>Javascript Directory: ' . realpath('../../../js') . '</p>';
echo '<p>CSS Directory: ' . realpath('../../../css') . '</p>';
?>