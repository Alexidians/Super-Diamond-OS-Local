<?php
echo '<p>System File: ' . realpath('../../../../System.bat') . '</p>';
echo '<p>OS File: ' . realpath('../../../../index.html') . '</p>';
echo '<p>Updater File: ' . realpath('../../../update.php') . '</p>';
echo '<p>Shortcut Finder File: ' . realpath('../../../load_shortcuts.php') . '</p>';
?>