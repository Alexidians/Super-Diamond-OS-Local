<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warning Message Receiver</title>
</head>
<body>
    <p><h1>Warning</h1></p>
    <center><div id="warning-message"></div></center>

    <script>
        MsgTimedout = false
        function receiveMessage(event) {
            if(!MsgTimedout) {
             document.getElementById('warning-message').textContent = event.data;
             clearInterval(timeoutTimer)
            } else {
             document.getElementById('warning-message').textContent = "Received Message After timed out already.";
            }
        }
        window.addEventListener('message', receiveMessage);
        timeoutTimer = setTimeout(function () {
            document.getElementById('warning-message').textContent = "Message timed out.";
            MsgTimedout = true
        }, 1000)
    </script>
</body>
</html>
