<?php
// Get the full path of the .SDAppSetup file from the query parameters
$filename = isset($_GET['filename']) ? $_GET['filename'] : '';

if (!empty($filename)) {
    // Resolve the full path of the file
    $file_path = $filename;
    if ($file_path) {
        // Open the zip file
        $zip = new ZipArchive;
        if ($zip->open($file_path) === TRUE) {
            // Extract to a temporary directory
            $temp_dir = sys_get_temp_dir() . '/' . uniqid('app_', true);
            mkdir($temp_dir);

            // Extract the contents of the zip file to the temporary directory
            $zip->extractTo($temp_dir);
            $zip->close();

            // Read the appName.txt file to determine the installation directory
            $app_name_file = $temp_dir . '/appName.txt';
            if (is_file($app_name_file)) {
                $app_name = trim(file_get_contents($app_name_file));
                $install_dir = '../../' . $app_name;

                // Create the installation directory if it doesn't exist
                if (!file_exists($install_dir)) {
                    mkdir($install_dir, 0755, true);
                }

                // Copy the contents of the temporary directory to the installation directory
                $iterator = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($temp_dir, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );

                foreach ($iterator as $item) {
                    $dest_path = $install_dir . DIRECTORY_SEPARATOR . $iterator->getSubPathName();
                    if ($item->isDir()) {
                        mkdir($dest_path);
                    } else {
                        copy($item, $dest_path);
                    }
                }

                // Clean up the temporary directory
                array_map('unlink', glob("$temp_dir/*.*"));
                rmdir($temp_dir);

                echo "<p>App installed successfully in $install_dir!</p>";
            } else {
                echo "<p>appName.txt file not found in the archive.</p>";
            }
        } else {
            echo "<p>Failed to open the .SDAppSetup file.</p>";
        }
    } else {
        echo "<p>File not found or inaccessible.</p>";
    }
} else {
    echo "<p>No file specified.</p>";
}
?>
