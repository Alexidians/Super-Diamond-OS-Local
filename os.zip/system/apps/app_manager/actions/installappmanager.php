<?php
// Check if form was submitted
if (isset($_POST['submit'])) {
    // Define target directory for file upload
    $target_dir = '../../'; // Adjust the directory path as per your application's structure

    // Define allowed file extension
    $allowed_extension = 'sdappsetup';

    // Check if a file was selected
    if (!empty($_FILES['sd_app_setup']['name'])) {
        $filename = $_FILES['sd_app_setup']['name'];
        $file_temp = $_FILES['sd_app_setup']['tmp_name'];

        // Validate file extension
        $file_extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($file_extension != $allowed_extension) {
            echo "<p>Invalid file type. Only .SDAppSetup files are allowed.</p>";
        } else {
            // Generate a unique installation directory name based on timestamp
            $timestamp = time();
            $install_dir_base = $target_dir . 'app_' . $timestamp;

            // Create the installation directory
            if (!mkdir($install_dir_base, 0755, true)) {
                die("<p>Failed to create installation directory.</p>");
            }

            // Move the uploaded file to the installation directory
            $dest_path = $install_dir_base . '/' . $filename;
            if (!move_uploaded_file($file_temp, $dest_path)) {
                die("<p>Failed to move uploaded file.</p>");
            }

            // Extract the contents of the .SDAppSetup file
            $zip = new ZipArchive;
            if ($zip->open($dest_path) === TRUE) {
                // Read appName.txt from the extracted archive
                $appNameFile = 'appName.txt';
                $appName = $zip->getFromName($appNameFile); // Get contents of appName.txt
                $appName = trim($appName); // Trim whitespace and newline characters

                // If appName.txt exists and contains a valid name
                if ($appName) {
                    // Update the installation directory path
                    $install_dir = $target_dir . $appName;

                    // Create the installation directory for the app
                    if (!mkdir($install_dir, 0755, true)) {
                        die("<p>Failed to create installation directory for the app.</p>");
                    }

                    // Extract files to the final installation directory
                    $zip->extractTo($install_dir);
                    $zip->close();

                    // Remove the temporary installation directory
                    if (is_dir($install_dir_base)) {
                        // Function to delete directory recursively
                        function deleteDirectory($dir) {
                            if (!file_exists($dir)) {
                                return true;
                            }
                            if (!is_dir($dir)) {
                                return unlink($dir);
                            }
                            foreach (scandir($dir) as $item) {
                                if ($item == '.' || $item == '..') {
                                    continue;
                                }
                                if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                                    return false;
                                }
                            }
                            return rmdir($dir);
                        }

                        if (!deleteDirectory($install_dir_base)) {
                            echo "<p>Failed to delete temporary installation directory.</p>";
                        }
                    }

                    echo "<p>App installed successfully in $install_dir!</p>";
                } else {
                    echo "<p>appName.txt file not found or empty in the app.</p>";
                }
            } else {
                echo "<p>Failed to open the .SDAppSetup file.</p>";
            }
        }
    } else {
        echo "<p>No file selected.</p>";
    }
    echo "<a href='../index.php'>Back</a>";
}
?>
