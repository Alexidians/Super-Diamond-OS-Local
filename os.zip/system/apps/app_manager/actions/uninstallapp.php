<?php
echo "<a href='../index.php'>Back</a>";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['app_name'])) {
    $appName = $_POST['app_name'];
    $appDir = '../../' . $appName;

    // Check if the app directory exists
    if (is_dir($appDir)) {
        // Attempt to delete the app directory and its contents
        if (deleteDirectory($appDir)) {
            echo "App '$appName' uninstalled successfully!";
        } else {
            echo "Error: Failed to uninstall app '$appName'.";
        }
    } else {
        echo "Error: App '$appName' not found.";
    }
} else {
    echo "Error: Invalid request.";
}

// Function to recursively delete a directory and its contents
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }

    return rmdir($dir);
}
?>
