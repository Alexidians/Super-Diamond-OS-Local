<?php
echo "<a href='../index.php'>Back</a>";
$appName = $_GET['app_name'] ?? null;
$zipUrl = $_GET['zip_url'] ?? null;

if (!$appName || !$zipUrl) {
    die('Error: Missing parameters.');
}

$targetDir = '../../'; // Adjust the target directory as needed

// Download the .zip file
$tempFile = tempnam(sys_get_temp_dir(), 'app_update_');
$zipResource = fopen($tempFile, 'w');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $zipUrl);
curl_setopt($ch, CURLOPT_FILE, $zipResource);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_FAILONERROR, true); // Ensure that HTTP errors are reported
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification
curl_exec($ch);

if (curl_errno($ch)) {
    fclose($zipResource);
    unlink($tempFile);
    die('Error: Failed to download .zip file - ' . curl_error($ch));
}

curl_close($ch);
fclose($zipResource);

// Extract the contents of the .zip file to a temporary directory
$tempDir = sys_get_temp_dir() . '/' . uniqid('app_update_', true);
if (!mkdir($tempDir, 0777, true)) {
    unlink($tempFile);
    die('Error: Failed to create temporary directory.');
}

$zip = new ZipArchive;
if ($zip->open($tempFile) === true) {
    if (!$zip->extractTo($tempDir)) {
        $zip->close();
        unlink($tempFile);
        rmdir($tempDir);
        die('Error: Failed to unzip the file.');
    }
    $zip->close();
} else {
    unlink($tempFile);
    rmdir($tempDir);
    die('Error: Failed to open the .zip file.');
}

unlink($tempFile); // Clean up the downloaded zip file

// Update the app files
$appDir = rtrim($targetDir, '/') . '/' . $appName;

if (!is_dir($appDir)) {
    die("Error: App '$appName' not found.");
}

// Function to recursively copy files and directories
function recursive_copy($source, $dest) {
    $source = rtrim($source, '/');
    $dest = rtrim($dest, '/');

    if (is_dir($source)) {
        @mkdir($dest, 0777, true);
        $dir = opendir($source);
        while (($file = readdir($dir)) !== false) {
            if ($file != '.' && $file != '..') {
                recursive_copy("$source/$file", "$dest/$file");
            }
        }
        closedir($dir);
    } else {
        copy($source, $dest);
    }
}

// Copy updated files to the app directory
recursive_copy($tempDir, $appDir);

// Clean up the temporary directory
function recursive_delete($dir) {
    if (!is_dir($dir)) {
        return;
    }

    $items = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($items as $item) {
        if ($item->isDir()) {
            rmdir($item->getRealPath());
        } else {
            unlink($item->getRealPath());
        }
    }

    rmdir($dir);
}

recursive_delete($tempDir);

echo "App '$appName' updated successfully!";
?>
