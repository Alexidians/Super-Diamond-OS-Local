<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Manager</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Application Manager</h1>

        <!-- Form for installing a new app from .SDAppSetup file -->
        <form action="actions/installappmanager.php" method="post" enctype="multipart/form-data">
            <h2>Install New App from .SDAppSetup</h2>
            <input type="file" name="sd_app_setup" accept=".SDAppSetup" required>
            <button type="submit" name="submit">Install</button>
        </form>
        
        <p><button onclick="parent.loadShortcuts()">Reload Shortcuts</button></p>
        
        <!-- Search input field -->
        <div class="search-container">
            <input type="text" id="searchInput" onkeyup="filterApps()" placeholder="Search for apps...">
        </div>

        <h2>Manage Apps</h2>
        <div class="apps-list">
            <?php
            $appDir = '../';
            $iconDefault = '../../icons/appdefault.png';

            function read_file_content($file_path, $default = null) {
                if (file_exists($file_path)) {
                    return file_get_contents($file_path);
                }
                return $default;
            }

            $apps = [];
            $appFolders = array_diff(scandir($appDir), ['.', '..']);
            foreach ($appFolders as $appFolder) {
                $appPath = $appDir . '/' . $appFolder;
                if (is_dir($appPath)) {
                    $iconPath = $appPath . '/icon.png';
                    $titlePath = $appPath . '/title.txt';
                    $shortcutPath = $appPath . '/shortcut.txt';
                    $updateUrlPath = $appPath . '/updateurl.txt';
                    $appName = basename($appPath);

                    $icon = file_exists($iconPath) ? $iconPath : $iconDefault;
                    $title = read_file_content($titlePath, 'Unknown App');
                    $shortcut = read_file_content($shortcutPath, 'false');
                    $updateUrl = read_file_content($updateUrlPath);

                    $apps[] = [
                        'icon' => $icon,
                        'title' => $title,
                        'shortcut' => $shortcut,
                        'update_url' => $updateUrl,
                        'appName' => $appName
                    ];
                }
            }

            foreach ($apps as $index => $app) {
                echo "<div class='app' id='app$index'>";
                echo "<img width='48px' height='48px' src='{$app['icon']}' alt='{$app['appName']}'>";
                echo "<h3>{$app['title']} ({$app['appName']})</h3>";
                echo "<p>Shortcut: " . ($app['shortcut'] === 'true' ? 'Yes' : 'No') . "</p>";
                if ($app['update_url']) {
                    echo "<form action='actions/updateapp.php' method='get'>";
                    echo "<input type='hidden' name='app_name' value='{$app['appName']}'>";
                    echo "<input type='hidden' name='zip_url' value='{$app['update_url']}'>";
                    echo "<button type='submit'>Update</button>";
                    echo "</form>";
                } else {
                    echo "<button onclick='parent.ErrorMessage(`{$app['title']} ({$app['appName']}) does not have an update url associated with it. TIP: builtin apps update together with the OS.`)'> Update</button>";
                }
                echo "<form action='actions/uninstallapp.php' method='post'>";
                echo "<input type='hidden' name='app_name' value='{$app['appName']}'>";
                echo "<button type='submit'>Uninstall</button>";
                echo "</form>";

                echo "</div>";
            }
            ?>
        </div>
    </div>

    <script>
        // Function to filter apps based on search input
        function filterApps() {
            let input = document.getElementById('searchInput').value.toUpperCase();
            let apps = document.querySelectorAll('.app');

            apps.forEach(app => {
                let title = app.querySelector('h3').textContent.toUpperCase();
                if (title.includes(input)) {
                    app.style.display = '';
                } else {
                    app.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
