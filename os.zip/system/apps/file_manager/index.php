<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple File Manager</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            border-bottom: 1px solid #ccc;
            padding-bottom: 5px;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin-bottom: 5px;
        }
        textarea {
            width: 100%;
            min-height: 300px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
        }
        .run-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            text-decoration: none;
            display: inline-block;
            border-radius: 4px;
        }
        .run-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<h2>Simple File Manager</h2>

<?php
$base_dir = realpath('../../../') . '/'; // Base directory
$current_dir = isset($_GET['dir']) ? rtrim($_GET['dir'], '/') . '/' : ''; // Current directory

// Resolve file path function
function resolveFilePath($filename, $current_dir, $base_dir) {
    // Construct the full path to the file
    $requested_path = realpath($base_dir . DIRECTORY_SEPARATOR . $current_dir . DIRECTORY_SEPARATOR . $filename);

    // Check if the resolved path exists and is a file
    if ($requested_path && is_file($requested_path)) {
        return $requested_path;
    } else {
        return false;
    }
}

// Function to get list of applications in the base directory
function getApplications() {
    $apps = [];

    $files = scandir(".." . DIRECTORY_SEPARATOR);
    foreach ($files as $file) {
        $file_path = ".." . DIRECTORY_SEPARATOR . $file;
        if (is_dir($file_path) && file_exists($file_path . '/run.php')) {
            $apps[] = $file;
        }
    }

    return $apps;
}

// Handle actions
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $filename = isset($_GET['filename']) ? $_GET['filename'] : '';

    if ($action == 'view') {
        if (!empty($filename)) {
            // Resolve file path using $filename (treated as file name)
            $file_path = resolveFilePath($filename, $current_dir, $base_dir);
            if ($file_path && is_file($file_path)) {
                echo "<h3>Viewing: $filename</h3>";
                echo "<a href='?dir=$current_dir'>Back to file manager</a><br><br>";

                // Display file contents
                echo "<pre>";
                readfile($file_path);
                echo "</pre>";

                // Display applications to run with
                $applications = getApplications();
                if (!empty($applications)) {
                    echo "<p>Select an application to run with:</p>";
                    echo "<ul>";
                    foreach ($applications as $app) {
                        $app_name = htmlspecialchars($app);
                        $app_url = htmlspecialchars('?action=run&filename=' . $filename . '&app=' . $app);
                        echo "<li><a href='$app_url' class='run-btn'>Run with $app_name</a></li>";
                    }
                    echo "</ul>";
                } else {
                    echo "<p>No applications available to run with this file.</p>";
                }
            } else {
                echo "<p>File not found or inaccessible.</p>";
            }
        } else {
            // Handle viewing a directory
            echo "<h3>Current directory: $current_dir</h3>";
            echo "<ul>";
            if ($current_dir != $base_dir) {
                echo "<li><a href='?parent&dir=$current_dir'>../</a></li>"; // Link to parent directory
            }
            $files = scandir($base_dir . $current_dir);
            foreach ($files as $file) {
                $file_path = $base_dir . $current_dir . $file;
                if ($file == '.' || $file == '..') continue;
                echo "<li>";
                if (is_dir($file_path)) {
                    echo "<strong>$file/</strong> | ";
                    echo "<a href='?action=view&dir=$current_dir$file/'>View</a> | ";
                } else {
                    echo "<a href='?action=view&dir=$current_dir&filename=$file'>$file</a> | ";
                }
                echo "<a href='?action=edit&dir=$current_dir&filename=$file'>Edit</a> | ";
                echo "<a href='?action=delete&dir=$current_dir&filename=$file' onclick='return confirm(\"Are you sure you want to delete $file?\")'>Delete</a></li>";
            }
            echo "</ul>";

            // Display the file upload form
            echo "<h3>Upload a file</h3>";
            echo "<form action='?action=upload&dir=$current_dir' method='post' enctype='multipart/form-data'>";
            echo "<input type='file' name='fileToUpload' id='fileToUpload'><br><br>";
            echo "<input type='submit' value='Upload File' name='submit'>";
            echo "</form>";
        }
    } elseif ($action == 'edit') {
        // Resolve file path using $filename (treated as file name)
        $file_path = resolveFilePath($filename, $current_dir, $base_dir);
        if ($file_path && is_file($file_path)) {
            echo "<h3>Editing: $filename</h3>";
            echo "<form action='?action=save&dir=$current_dir&filename=$filename' method='post'>";
            echo "<textarea name='filecontent'>";
            echo htmlentities(file_get_contents($file_path));
            echo "</textarea><br>";
            echo "<input type='submit' value='Save Changes'>";
            echo "</form>";
        } else {
            echo "<p>File not found or inaccessible.</p>";
        }
    } elseif ($action == 'save') {
        // Resolve file path using $filename (treated as file name)
        $file_path = resolveFilePath($filename, $current_dir, $base_dir);
        if ($file_path && is_file($file_path)) {
            $filecontent = $_POST['filecontent'];
            file_put_contents($file_path, $filecontent);
            echo "<p>Changes saved successfully!</p>";
            echo "<a href='?action=view&dir=$current_dir&filename=$filename'>View File</a>";
        } else {
            echo "<p>File not found or inaccessible.</p>";
        }
    } elseif ($action == 'delete') {
        // Resolve file path using $filename (treated as file name)
        $file_path = resolveFilePath($filename, $current_dir, $base_dir);
        if ($file_path && is_file($file_path)) {
            if (unlink($file_path)) {
                echo "<p>$filename deleted successfully!</p>";
            } else {
                echo "<p>Error deleting $filename.</p>";
            }
            echo "<a href='?dir=$current_dir'>Back to file manager</a>";
        } else {
            echo "<p>File not found or inaccessible.</p>";
        }
    } elseif ($action == 'upload') {
        $target_dir = $base_dir . $current_dir;
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "<p>Sorry, file already exists.</p>";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "<p>Sorry, your file was not uploaded.</p>";
        } else {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                echo "<p>The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.</p>";
            } else {
                echo "<p>Sorry, there was an error uploading your file.</p>";
                echo "<p>Error details: " . $_FILES["fileToUpload"]["error"] . "</p>";
            }
        }
        echo "<a href='?dir=$current_dir'>Back to file manager</a>";
    } elseif ($action == 'run' && isset($_GET['app'])) {
        $app_name = $_GET['app'];
        $file_path = resolveFilePath($filename, $current_dir, $base_dir);
        if ($file_path && is_file($file_path)) {
            $app_url = htmlspecialchars("../$app_name/run.php?filemanager&file=" . urlencode($file_path));
            echo "<h3>Running $filename with $app_name</h3>";
            echo "<iframe src='$app_url' style='border: 1px solid #ccc; width: 100%; min-height: 300px;'></iframe>";
            echo "<br><a href='?action=view&dir=$current_dir&filename=$filename'>Back to file manager</a>";
        } else {
            echo "<p>File not found or inaccessible.</p>";
        }
    }
} else {
    // Display file list in current directory
    echo "<h3>Current directory: $current_dir</h3>";
    echo "<ul>";
    if ($current_dir != $base_dir) {
        echo "<li><a href='?parent&dir=$current_dir'>../</a></li>"; // Link to parent directory
    }
    $files = scandir($base_dir . $current_dir);
    foreach ($files as $file) {
        $file_path = $base_dir . $current_dir . $file;
        if ($file == '.' || $file == '..') continue;
        echo "<li>";
        if (is_dir($file_path)) {
            echo "<strong>$file/</strong> | ";
            echo "<a href='?action=view&dir=$current_dir$file/'>View</a> | ";
        } else {
            echo "<a href='?action=view&dir=$current_dir&filename=$file'>$file</a> | ";
        }
        echo "<a href='?action=edit&dir=$current_dir&filename=$file'>Edit</a> | ";
        echo "<a href='?action=delete&dir=$current_dir&filename=$file' onclick='return confirm(\"Are you sure you want to delete $file?\")'>Delete</a></li>";
    }
    echo "</ul>";

    // Display the file upload form
    echo "<h3>Upload a file</h3>";
    echo "<form action='?action=upload&dir=$current_dir' method='post' enctype='multipart/form-data'>";
    echo "<input type='file' name='fileToUpload' id='fileToUpload'><br><br>";
    echo "<input type='submit' value='Upload File' name='submit'>";
    echo "</form>";
}
?>

</body>
</html>
