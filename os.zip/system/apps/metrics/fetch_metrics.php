<?php
// Function to fetch and return global system metrics as JSON
function fetchGlobalMetrics() {
    $metrics = [];

    // Get CPU Usage
    $cpuUsage = shell_exec('powershell "Get-CimInstance -ClassName Win32_Processor | Measure-Object -Property LoadPercentage -Average | Select-Object -ExpandProperty Average"');
    $metrics['cpu_usage'] = round(floatval($cpuUsage), 2);

    // Get Memory Usage
    $memoryUsage = shell_exec('powershell "Get-CimInstance -ClassName Win32_OperatingSystem | Select-Object TotalVisibleMemorySize, FreePhysicalMemory | ForEach-Object { $_.TotalVisibleMemorySize, $_.FreePhysicalMemory }"');
    $memoryUsageArr = explode("\n", $memoryUsage);
    if (count($memoryUsageArr) >= 2) {
        $totalMemory = intval(trim($memoryUsageArr[0]));
        $freeMemory = intval(trim($memoryUsageArr[1]));
        $usedMemory = $totalMemory - $freeMemory;
        $metrics['memory_usage'] = [
            'used' => round($usedMemory / 1024 / 1024, 2), // Convert to MB and round to 2 decimal places
            'total' => round($totalMemory / 1024 / 1024, 2) // Convert to MB and round to 2 decimal places
        ];
    } else {
        $metrics['memory_usage'] = [
            'used' => 0,
            'total' => 0
        ];
    }

    // Get Network Usage (Upload and Download in bytes/sec)
    $networkUsage = shell_exec('powershell "Get-NetAdapterStatistics | Select-Object -Property Name, ReceivedBytes, SentBytes"');
    $networkUsageArr = explode("\n", $networkUsage);
    $upload = 0;
    $download = 0;
    foreach ($networkUsageArr as $line) {
        if (strpos($line, 'Ethernet') !== false || strpos($line, 'Wi-Fi') !== false) {
            $stats = preg_split('/\s+/', trim($line));
            if (count($stats) >= 6) { // Check if array has enough elements
                $download += intval($stats[4]);
                $upload += intval($stats[6]);
            }
        }
    }
    $metrics['network_usage'] = [
        'upload' => $upload,
        'download' => $download
    ];

    // Return metrics as JSON
    header('Content-Type: application/json');
    echo json_encode($metrics);
}

// Fetch and return global system metrics
fetchGlobalMetrics();
?>
