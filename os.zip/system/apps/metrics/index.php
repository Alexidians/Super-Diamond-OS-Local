<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metrics</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .metrics-item {
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
        }
        .metrics-item h2 {
            margin-top: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Metrics</h1>
        <div id="metrics">
            <div class="metrics-item" id="cpuMetrics">
                <h2>CPU Usage</h2>
                <p>Average CPU Usage: <span id="cpuUsage">Fetching...</span>%</p>
            </div>
            <div class="metrics-item" id="memoryMetrics">
                <h2>Memory Usage</h2>
                <p>Used Memory: <span id="usedMemory">Fetching...</span> MB</p>
                <p>Total Memory: <span id="totalMemory">Fetching...</span> MB</p>
            </div>
            <div class="metrics-item" id="networkMetrics">
                <h2>Network Usage</h2>
                <p>Upload: <span id="upload">Fetching...</span> bytes/sec</p>
                <p>Download: <span id="download">Fetching...</span> bytes/sec</p>
            </div>
        </div>
    </div>

    <script>
        // Function to update metrics
        function updateMetrics() {
            fetch('metrics/fetch_metrics.php')
                .then(response => response.json())
                .then(data => {
                    // Update CPU metrics
                    document.getElementById('cpuUsage').innerText = data.cpu_usage.toFixed(2);
                    
                    // Update Memory metrics
                    document.getElementById('usedMemory').innerText = data.memory_usage.used.toFixed(2);
                    document.getElementById('totalMemory').innerText = data.memory_usage.total.toFixed(2);
                    
                    // Update Network metrics
                    document.getElementById('upload').innerText = data.network_usage.upload.toFixed(2);
                    document.getElementById('download').innerText = data.network_usage.download.toFixed(2);
                })
                .catch(error => {
                    console.error('Error fetching metrics:', error);
                });
        }

        // Update metrics every second
        setInterval(updateMetrics, 1000);
    </script>
</body>
</html>
