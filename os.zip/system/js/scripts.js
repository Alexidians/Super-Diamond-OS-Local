async function openApp(appName, file='index.php') {
    const desktop = document.getElementById('desktop');
    const windowDiv = document.createElement('div');
    windowDiv.className = 'window';
    const iframeId = `OpenAppIframe`;
    let titleText = appName;
    try {
        const titleResponse = await fetch(`system/apps/${appName}/title.txt`);
        if (titleResponse.ok) {
            titleText = await titleResponse.text();
        } else {
            console.error('Title file not found');
        }
    } catch (error) {
        console.error('Error fetching title:', error.message);
    }
    let iconUrl = `system/apps/${appName}/icon.png`;
    let iconResponse;
    try {
        iconResponse = await fetch(iconUrl);
        if (!iconResponse.ok) {
            throw new Error('Icon not found');
        }
    } catch (error) {
        iconUrl = 'system/icons/appdefault.png';
    }
    windowDiv.innerHTML = `
        <div class="title-bar">
            <img class="app-icon" src="${iconUrl}" alt="App Icon">
            <div class="title">${titleText.trim()}</div>
            <div class="close-button" onclick="closeWindow(this)">X</div>
        </div>
        <div class="iframe-container">
            <iframe id="${iframeId}" src="system/apps/${appName}/${file}"></iframe>
        </div>
    `;
    desktop.appendChild(windowDiv);
    dragElement(windowDiv);
    const iframeElement = document.getElementById(iframeId);
    iframeElement.removeAttribute('id');
    return iframeElement.contentWindow;
}




function update() {
    fetch('system/update.php', {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            ErrorMessage("Failed to update OS Due to not ok response code: " + response.status + ".")
        }
        return response.text();
    })
    .then(data => {
        WarningMessage('Restart the os console for changes to apply.')
    })
    .catch(error => {
        ErrorMessage('Failed to update OS due to js error.');
    });
}

async function WarningMessage(msg) {
    wind = await openApp("WarningMessagePopup")
    wind.postMessage(msg)
    setTimeout(function sendMsg(msge, windo) {
       windo.postMessage(msge)
    }, 100, msg, wind)
}

async function ErrorMessage(msg) {
    wind = await openApp("ErrorMessagePopup")
    wind.postMessage(msg)
    setTimeout(function sendMsg(msge, windo) {
       windo.postMessage(msge)
    }, 100, msg, wind)
}

function closeWindow(button) {
    const windowDiv = button.closest('.window');
    if (windowDiv) {
        windowDiv.remove();
    }
}

function dragElement(elmnt) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    const titleBar = elmnt.querySelector('.title-bar');
    if (titleBar) {
        // if present, the title bar is where you move the DIV from:
        titleBar.onmousedown = dragMouseDown;
    } else {
        // otherwise, move the DIV from anywhere inside the DIV:
        elmnt.onmousedown = dragMouseDown;
    }

    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
        elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
    }

    function closeDragElement() {
        // stop moving when mouse button is released:
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

function loadShortcuts() {
    const shortcutsContainer = document.getElementById('desktop');
    const existingShortcuts = document.getElementsByClassName('shortcut');
    for (let i = existingShortcuts.length - 1; i >= 0; i--) {
        const shortcut = existingShortcuts[i];
        shortcut.parentNode.removeChild(shortcut);
    }
    fetch('system/load_shortcuts.php')
        .then(response => response.json())
        .then(data => {
            data.shortcuts.forEach(shortcut => {
                const shortcutDiv = document.createElement('div');
                shortcutDiv.className = 'shortcut';
                shortcutDiv.innerHTML = `
                    <img src="${shortcut.icon}" alt="${shortcut.name}">
                    <span>${shortcut.name}</span>
                `;
                shortcutDiv.onclick = () => openApp(shortcut.appName);
                shortcutsContainer.appendChild(shortcutDiv);
            });
        })
        .catch(error => console.error('Error loading custom shortcuts:', error));
}


function checkServerStatus() {
    const origin = window.location.origin;
    fetch(`${origin}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Server not reachable');
            }
        })
        .catch(error => {
            clearInterval(statusChecker)
            try {
             ErrorMessage("System is offline. shutdown in 3.")
             setTimeout(function() {
                ErrorMessage("System is offline. shutdown in 2.")
                setTimeout(function() {
                    ErrorMessage("System is offline. shutdown in 1.")
                    setTimeout(function() {
                        document.body.innerHTML = '';
                        document.body.style.backgroundColor = 'black';
                    }, 1000)
                }, 1000)
             }, 1000)
            } catch(err) {
             document.body.innerHTML = '';
             document.body.style.backgroundColor = 'black';
            }
        });
}
checkServerStatus();
statusChecker = setInterval(checkServerStatus, 5000);