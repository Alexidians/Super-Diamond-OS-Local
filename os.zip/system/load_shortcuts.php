<?php

$appsFolder = 'apps/';

// Function to check if a directory contains a file
function directoryContainsFile($dir, $filename) {
    return is_dir($dir) && file_exists($dir . $filename);
}

// Initialize array to store shortcuts
$shortcuts = array();

// Open the apps directory
if ($handle = opendir($appsFolder)) {
    // Loop through each directory (app) in the apps folder
    while (false !== ($app = readdir($handle))) {
        // Skip over '.' and '..' which represent current and parent directory
        if ($app != "." && $app != "..") {
            // Check if shortcut.txt exists and is 'true'
            $shortcutFile = $appsFolder . $app . '/shortcut.txt';
            if (directoryContainsFile($appsFolder . $app . '/', 'shortcut.txt')) {
                $shortcutText = trim(file_get_contents($shortcutFile));
                if (strtolower($shortcutText) === 'true') {
                    // Fetch title.txt for the app name
                    $titleFile = $appsFolder . $app . '/title.txt';
                    if (directoryContainsFile($appsFolder . $app . '/', 'title.txt')) {
                        $appName = trim(file_get_contents($titleFile));

                        // Prepare icon path
                        if(file_exists($appsFolder . $app . '/icon.png')) {
                         $iconPath = "system/" . $appsFolder . $app . '/icon.png';
                        } else {
                            $iconPath = "system/icons/appdefault.png";
                        }

                        // Add shortcut information to the array
                        $shortcuts[] = array(
                            'appName' => $app,
                            'name' => $appName,
                            'icon' => $iconPath
                        );
                    }
                }
            }
        }
    }
    closedir($handle);
}

// Output shortcuts as JSON
header('Content-Type: application/json');
echo json_encode(array('shortcuts' => $shortcuts));
