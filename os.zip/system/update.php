<?php
$zipUrl = "https://alexidians.github.io/Super-Diamond-OS-Local/os.zip";
$zipFile = "os.zip";
$extractTo = "../";
$tempExtractPath = "temp_extract/";
file_put_contents($zipFile, fopen($zipUrl, 'r'));
$zip = new ZipArchive;
if ($zip->open($zipFile) === TRUE) {
    if (!file_exists($tempExtractPath)) {
        mkdir($tempExtractPath);
    }
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $filename = $zip->getNameIndex($i);
        if (basename($filename) == 'update.php' || basename($filename) == 'System.bat') {
            continue;
        }
        $extractedFilePath = $extractTo . $filename;
        if (substr($filename, -1) === '/') {
            mkdir($extractedFilePath, 0777, true);
        } else {
            $zip->extractTo($tempExtractPath, array($filename));
            if (file_exists($extractedFilePath)) {
                unlink($extractedFilePath);
            }
            rename($tempExtractPath . $filename, $extractedFilePath);
        }
    }
    $zip->close();
    if (file_exists($tempExtractPath)) {
        rmdir($tempExtractPath);
    }
    if (file_exists($zipFile)) {
        unlink($zipFile);
    }
    echo "Extraction complete.";
} else {
    echo "Failed to open the ZIP file.";
}
?>
